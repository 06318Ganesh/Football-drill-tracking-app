const express = require("express");
const Drill = require("../models/Drill");
const UserDrill = require("../models/UserDrill");
const router = express.Router();

// Get all drills
router.get("/", async (req, res) => {
  try {
    const drills = await Drill.find();
    res.status(200).json(drills);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Submit drill count
router.post("/:id/submit", async (req, res) => {
  try {
    const { userId, enteredCount } = req.body;
    const drill = await Drill.findById(req.params.id);
    if (enteredCount > drill.totalCount)
      return res.status(400).json({ message: "Entered count exceeds total count" });

    const userDrill = new UserDrill({
      userId,
      drillId: req.params.id,
      enteredCount,
    });
    await userDrill.save();
    res.status(201).json({ message: "Drill count submitted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
