const mongoose = require("mongoose");

const drillSchema = new mongoose.Schema({
  name: { type: String, required: true },
  totalCount: { type: Number, required: true },
  image: { type: String, required: true },
});

module.exports = mongoose.model("Drill", drillSchema);
